# Change Log

## [Unreleased]

## [v0.2.0] - 2021-06-18

### Changed

* Constructors and accessors on the `Function` and `Reason` types have been made private APIs.

### Added

* Added support for OpenSSL 3.x.x.

## v0.1.0 - 2019-03-14

Initial release

[Unreleased]: https://github.com/sfackler/rust-openssl/compare/openssl-errors-v0.2.0...master
[v0.2.0]: https://github.com/sfackler/rust-openssl/compare/openssl-errors-v0.1.0...openssl-errors-v0.2.0
